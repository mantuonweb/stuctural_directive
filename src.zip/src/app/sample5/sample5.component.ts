import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'sample5',
    template: `
        <span>I am first span</span>
       
        <span>I am last span </span>
    `
})
export class Sample5Component {}