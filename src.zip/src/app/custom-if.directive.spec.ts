import { CustomIfDirective } from './custom-if.directive';

describe('CustomIfDirective', () => {
  it('should create an instance', () => {
    
  });
});
